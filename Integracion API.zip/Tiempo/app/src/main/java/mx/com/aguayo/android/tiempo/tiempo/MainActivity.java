package mx.com.aguayo.android.tiempo.tiempo;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONException;

import java.util.ArrayList;

import mx.com.aguayo.android.tiempo.model.Weather;


public class MainActivity extends ActionBarActivity {

    ListView listado;

    ArrayList<ListClass> elementos;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String city = "Cancun,MX";

        listado= (ListView) findViewById(R.id.listado);

        elementos = new ArrayList<ListClass>();


        JSONWeatherTask task = new JSONWeatherTask();

        task.execute(new String[]{city});



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class JSONWeatherTask extends AsyncTask<String, Void, Weather> {

        @Override
        protected Weather doInBackground(String... params) {
            Weather weather = new Weather();
            String data = ( (new WeatherHttpClient()).getWeatherData(params[0]));

            try {
                weather = JSONWeatherParser.getWeather(data);

                // Let's retrieve the icon


            } catch (JSONException e) {
                e.printStackTrace();
            }
            return weather;

        }




        @Override
        protected void onPostExecute(Weather weather) {
            super.onPostExecute(weather);

            elementos.add(new ListClass("Domingo",weather.location.getCity() + "," + weather.currentCondition.getCondition(),"" + Math.round((weather.temperature.getTemp() - 273.15)) + "°C",R.drawable.ic_launcher));

            adapter adapterElements = new adapter(elementos,MainActivity.this.getApplicationContext());

            listado.setAdapter(adapterElements);
            listado.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> pariente, View view, int posicion, long id) {

                    ListClass seleccionado = (ListClass) pariente.getItemAtPosition(posicion);

                    Intent intent = new Intent(getBaseContext(), second_activity.class);

                    intent.putExtra("dia", seleccionado.getDia());
                    intent.putExtra("estado", seleccionado.getEstado());
                    intent.putExtra("temperatura", seleccionado.getTemperatura());
                    intent.putExtra("imagen", seleccionado.getImagen());
                    startActivity(intent);
                }
            });
        }

    }
}