package mx.com.aguayo.android.tiempo.tiempo;

/**
 * Created by CNU40196YT on 05/07/2015.
 */
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class second_activityFragment extends Fragment {

    public second_activityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second_activity, container, false);
    }
}

